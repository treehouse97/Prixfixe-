
GOOGLE_API_KEY = ""  # <-- Paste your Google Maps API key here
DEFAULT_LOCATION = "New York, NY"
SEARCH_RADIUS_METERS = 5000
