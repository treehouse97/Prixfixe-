
from backend.scraper.ingest_places import ingest_and_scrape

if __name__ == '__main__':
    ingest_and_scrape()
